To Run Tests
1) copy tests dir to you project root
2) on linux shell: ./run_test.sh path_to_your_executable_binary_file

Create Random Tests
1) make sure you copied tests dir to you project root
2) copy test_creator_helper.py
3) change test name and number of lines in test_creator_helper.py
4) run: python3 ./test_creator_helper.py

